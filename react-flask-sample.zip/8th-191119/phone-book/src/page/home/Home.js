import React, { Fragment, Component } from 'react';
import { Button } from 'antd';

class Home extends Component {

    render() {
        return (
            <Fragment >
                <div> Home </div>
            </Fragment>
        );
    }
}
export default Home;
