import React, { Fragment, Component } from 'react';
import { Input, Button } from 'antd'
class Home extends Component {
    render() {
        return (
            <Fragment >
               Home
            </Fragment>
        );
    }
}
export default Home;
